package MergeSort;

/**
 * Класс перечислений, определяющий тип данных
 */
public enum TypeInputFiles {
    INTEGER,
    STRING
}
