package MergeSort;

public class ParseIntException extends Exception {}
