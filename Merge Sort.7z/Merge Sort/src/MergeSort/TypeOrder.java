package MergeSort;

/**
 * Класс перечислений, определяющий порядок сортировки
 */
public enum TypeOrder {
    ASCENDING,
    DESCENDING
}
